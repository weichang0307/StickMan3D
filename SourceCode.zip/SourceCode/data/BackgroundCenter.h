#ifndef BACKGROUNDCENTER_H_INCLUDED
#define BACKGROUNDCENTER_H_INCLUDED

#include "../3D/Scene.h"
#include "../3D/Camera.h"
#include "../enemies/Enemy.h"
#include "../shapes3D/Polygon.h"
#include <vector>
#include <memory>
class BackgroundCenter
{
private:
    BackgroundCenter(){};
public:
    
    static BackgroundCenter *get_instance() {
		static BackgroundCenter BC;
		return &BC;
	}
    ~BackgroundCenter(){};
    void init();
    std::vector<std::shared_ptr<Polygon>> stones;
    Polygon ground;
};



#endif
