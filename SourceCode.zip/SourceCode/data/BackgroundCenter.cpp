#include "BackgroundCenter.h"
#include "ThreeDCenter.h"
#include <memory>
#include <math.h>
#include <random>
#ifndef PI
#define PI 3.14159265358979323846
#endif

void BackgroundCenter::init(){
    ThreeDCenter *TC = ThreeDCenter::get_instance();

    int radius = 5000;
    for(int i=0;i<360;i+=10){
        double x = radius * cos(i * PI / 180);
        double y = radius * sin(i * PI / 180);
        auto pt = std::make_shared<Point3D>(x, y, 0);
        ground.add(pt);
    }
    ground.set_color(40, 15, 0);
    TC->background.add(&ground);

    std::random_device rd;
    std::mt19937 gen(rd()); 
    std::uniform_real_distribution<> dis1(-radius, radius); 
    std::uniform_real_distribution<> dis2(50, 100); 
    std::uniform_real_distribution<> dis3(1, 3); 
    std::uniform_real_distribution<> dis4(30, 80); 

    double x, y;
    for(int i=0;i<2000;i++){
        do{
            x = 2 * dis1(gen);
            y = 2 * dis1(gen);
        }while (x * x + y * y > radius * radius);
        auto st = std::make_shared<Polygon>(x, y, 0);
        for(double angle = 0; angle < PI * 2; angle += dis3(gen)){
            double r = dis2(gen);
            x = r * cos(angle);
            y = r * sin(angle);
            auto pt = std::make_shared<Point3D>(x, y, 0);
            st->add(pt);
        }
        int f = dis4(gen);
        st->set_color(f, f / 3, 0);
        TC->background.add(&(*st));
        stones.push_back(st);
    }
    TC->background.add(&ground);
}
