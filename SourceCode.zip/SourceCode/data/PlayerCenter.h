#ifndef PLAYERCENTER_H_INCLUDED
#define PLAYERCENTER_H_INCLUDED

#include <vector>
#include <memory>
#include "../player/Player.h"
#include "../data/ThreeDCenter.h"
#include "../data/DataCenter.h"
class PlayerCenter
{
private:
    PlayerCenter(){
	    ThreeDCenter *TC = ThreeDCenter::get_instance();
        player.add_to_scene(TC->scene, TC->floor);
    };
public:
    
    static PlayerCenter *get_instance() {
		static PlayerCenter PC;
		return &PC;
	}
    ~PlayerCenter(){};
    void update(){
        DataCenter *DC = DataCenter::get_instance();
        player.update();
        if(player.pos.abs1() > DC->playground_radius){
            player.pos = player.pos.unit() * DC->playground_radius;
        }
    };
    void keydown(const int key){
        player.keydown(key);
    };
    void keyup(const int key){
        player.keyup(key);
    };
    Player player;
};



#endif