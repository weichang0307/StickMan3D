#ifndef THREEDCENTER_H_INCLUDED
#define THREEDCENTER_H_INCLUDED

#include "../3D/Scene.h"
#include "../3D/Camera.h"

class ThreeDCenter
{
public:
	static ThreeDCenter *get_instance() {
		static ThreeDCenter TC;
		return &TC;
	}
	
	~ThreeDCenter(){};
private:
	ThreeDCenter();
public:
    Scene scene, floor, background;
	Camera camera;
	double shift_theta = 0;
	void switch_view();
	void draw(){
		background.draw(camera);
		floor.draw(camera);
		scene.draw(camera);
		
		
	};
};

#endif
