#ifndef ENEMTCENTER_H_INCLUDED
#define ENEMTCENTER_H_INCLUDED

#include "../3D/Scene.h"
#include "../3D/Camera.h"
#include "../enemies/Enemy.h"
#include <vector>
#include <memory>
class EnemyCenter
{
private:
    EnemyCenter();
public:
    
    static EnemyCenter *get_instance() {
		static EnemyCenter EC;
		return &EC;
	}
    ~EnemyCenter(){};
    void update();
    void add(std::shared_ptr<Enemy> enm);
    void remove(std::shared_ptr<Enemy> enm);
    void add_ash(std::shared_ptr<Ash> ash);
    void remove_ash(std::shared_ptr<Ash> ash);
    void init_ash(std::shared_ptr<Enemy> &enm);
    void kill(std::shared_ptr<Enemy> enm);
    std::vector<std::shared_ptr<Enemy>> enemies;
    std::vector<std::shared_ptr<Ash>> ashes;
    
};



#endif
