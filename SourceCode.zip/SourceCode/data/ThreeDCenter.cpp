#include "ThreeDCenter.h"

ThreeDCenter::ThreeDCenter(){
    camera.dis = 500;
    background.is_sort = false;
    floor.is_sort = false;
}

void ThreeDCenter::switch_view(){
    if(shift_theta == 0){
        shift_theta = 0.5;
    }else{
        shift_theta = 0;
    }
}