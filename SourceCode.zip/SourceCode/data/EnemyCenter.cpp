#include "EnemyCenter.h"
#include "../enemies/EnemyA.h"
#include "ThreeDCenter.h"
#include <random>

EnemyCenter::EnemyCenter(){

}

void EnemyCenter::update(){
    std::vector<std::shared_ptr<Enemy>> dead;
    std::vector<std::shared_ptr<Ash>> gone;
    for(auto &enm : enemies){
        if(enm->HP <= 0){
            dead.push_back(enm);
            continue;
        }
        DataCenter *DC = DataCenter::get_instance();
        enm->update();
        if(enm->pos.abs1() > DC->playground_radius){
            enm->pos = enm->pos.unit() * DC->playground_radius;
        }
    }
    for(auto &enm: dead){
        init_ash(enm);
        remove(enm);
    }
    for(auto &ash : ashes){
        ash->update();
        if(ash->alpha < 0.001)gone.push_back(ash);
    }
    for(auto &ash : gone){
        remove_ash(ash);
    }
    if(enemies.size() == 0){
        int radius = 5000;
        for(int i=0;i<360;i+=5){
            double x = radius * cos(i * PI / 180);
            double y = radius * sin(i * PI / 180);
            auto ea1 = std::make_shared<EnemyA>();
            ea1->set_color(255,0,255);
            ea1->pos.x = x;
            ea1->pos.y = y;
            add(ea1);
        }
    }
    for(auto &enm1: enemies){
        for(auto &enm2 : enemies){
            Vector3 diff = enm1->pos - enm2->pos;
            diff.z = 0;
            double dis = diff.abs1();
            if(dis < 100){
                Vector3 move = diff.unit() * ((100 - dis) / 2);
                enm1->pos += move;
                enm2->pos -= move;
            }
        }
    }
    
    
}

void EnemyCenter::add(std::shared_ptr<Enemy> enm){
    ThreeDCenter *TC = ThreeDCenter::get_instance();
    enm->add_to_scene(TC->scene, TC->floor);
    enemies.push_back(enm);
}
void EnemyCenter::init_ash(std::shared_ptr<Enemy> &enm){
    double radius = enm->head.radius;
    std::random_device rd;
    std::mt19937 gen(rd()); 
    std::uniform_real_distribution<> dis1(-PI, PI); 
    std::uniform_real_distribution<> dis2(0, radius); 
    for(int i=0; i<30; i++){
        Vector3 p(dis2(gen), 0, 0);
        p.rotateY(dis1(gen) / 2);
        p.rotateZ(dis1(gen));
        p += enm->head.pos;
        add_ash(std::make_shared<Ash>(p, dis2(gen), enm->head.pos, 1));
    }   
    
}

void EnemyCenter::add_ash(std::shared_ptr<Ash> ash){
    ThreeDCenter *TC = ThreeDCenter::get_instance();
    ash->init();
    TC->scene.add(&(*ash));
    ashes.push_back(ash);
}
void EnemyCenter::remove(std::shared_ptr<Enemy> enm){
    ThreeDCenter *TC = ThreeDCenter::get_instance();
    enm->remove_from_scene(TC->scene, TC->floor);
    auto it =std::find(enemies.begin(), enemies.end(), enm);
    if(it != enemies.end())enemies.erase(it);
}
void EnemyCenter::remove_ash(std::shared_ptr<Ash> ash){
    ThreeDCenter *TC = ThreeDCenter::get_instance();
    TC->scene.remove(&(*ash));
    auto it = std::find(ashes.begin(), ashes.end(), ash);
    if(it != ashes.end())ashes.erase(it);
}