#include "EnemyCenter.h"
#include "ThreeDCenter.h"

EnemyCenter::EnemyCenter(){

}

void EnemyCenter::update(){
    for(auto &enm : enemies){
        enm->update();
    }
}

void EnemyCenter::add(std::shared_ptr<Enemy> enm){
    ThreeDCenter *TC = ThreeDCenter::get_instance();
    enm->add_to_scene(TC->scene, TC->floor);
    enemies.push_back(enm);
}