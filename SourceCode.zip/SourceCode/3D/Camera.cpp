#include "Camera.h"
#ifndef PI
#define PI 3.14159265358979323846
#endif


Vector3 Camera::direction() const{
    Vector3 dir(1,0,0);
    dir.rotateY(phi);
    dir.rotateZ(theta);
    return dir;
}

Vector3 Camera::position() const{
    Vector3 dir = direction();
    return Vector3(
        target.x - dis * dir.x,
        target.y - dis * dir.y,
        target.z - dis * dir.z
    );
}
