#include "Camera.h"
#ifndef PI
#define PI 3.14159265358979323846
#endif


Vector3 Camera::direction() const{
    Vector3 dir(1,0,0);
    dir.rotateY(phi);
    dir.rotateZ(theta);
    return dir;
}

Vector3 Camera::position() const{
    Vector3 dir = direction();
    return Vector3(
        target.x - dis * dir.x,
        target.y - dis * dir.y,
        target.z - dis * dir.z
    );
}

std::tuple<double, double, double, double, bool> Camera::project(const Vector3& v) const{
    double px, py, pz, ps;
    Vector3 camToPoint = v - position();
    pz = dot(direction(), camToPoint);
    if(pz == 0)return {0, 0, 0, 0, false};
    pz = pz / abs(pz) * camToPoint.abs1();
    camToPoint.rotateZ(-theta);
    camToPoint.rotateY(-phi);
    Vector3 direction = camToPoint.unit();
    px = - scale * direction.y;
    py = - scale * direction.z; 
    if(pz<0){
        double scale_ = scale / sqrt(px * px + py * py);
        px *= scale_;
        py *= scale_;
    }
    ps = scale / abs(pz);
    px += centerx;
    py += centery;
    return {px, py, pz, ps, true};
}
