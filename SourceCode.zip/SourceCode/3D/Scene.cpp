#include "Scene.h"
#include "../shapes3D/Drawable.h"
#include "algorithm"
#include <memory>
#include "iostream"
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>


void Scene::add(Drawable* dp){
    if(std::find(list.begin(), list.end(), dp) == list.end()) {
       list.push_back(dp); 
    }
}
void Scene::remove(Drawable* dp){
    list.erase(std::find(list.begin(), list.end(), dp));
}
void Scene::insert_sort() {
    if(list.empty())return;
    for (auto it = list.begin() + 1; it != list.end(); ++it) {
        auto current = *it;
        auto it1 = it;
        while (it1 != list.begin() && (*(it1 - 1))->closer(*current)) {
            *it1 = *(it1 - 1);
            --it1;
        }
        *it1 = current;
    }
}
void Scene::draw(const Camera& cam){
    for(Drawable* d : list){
        d->project(cam);
    }
    if(is_sort)insert_sort();
    int i;
    for(Drawable* d : list){
        i++;
        d->draw();
    }

}
