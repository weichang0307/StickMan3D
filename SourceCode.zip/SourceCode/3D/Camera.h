#ifndef CAMERA_H_INCLUDED
#define CAMERA_H_INCLUDED



#include "../shapes3D/Vector3.h"
#include "../data/DataCenter.h"
#include <cmath>
#include <tuple>

/**
 * @brief Camera for 3D view
 * @details Camera for 3D view
*/
class Scene;

class Camera
{
public:
    Camera() : theta(0), phi(0), dis(100), target(Vector3(0,0,0)){};
    Camera(double dis) : theta(0), phi(0), dis(dis), target(Vector3(0,0,0)){};
    Camera(double theta, double phi) : theta(theta), phi(phi), dis(100), target(Vector3(0,0,0)){};
    Camera(Vector3 target) : theta(0), phi(0), dis(100), target(target){};
    Camera(Vector3 target, double dis) : theta(0), phi(0), dis(dis), target(target){};
    Camera(Vector3 target, double dis, double theta, double phi) : theta(theta), phi(phi), dis(dis), target(target){};
	~Camera(){};

public:
    double theta, phi, dis;
    double scale = 1000;
    double centerx = DataCenter::get_instance()->window_width/2;
    double centery = DataCenter::get_instance()->window_height/2;
    Vector3 target;
    Vector3 direction() const;
    Vector3 position() const;
    std::tuple<double, double, double, double, bool> project(const Vector3& v) const;

};

#endif
