#ifndef SCENE_H_INCLUDED
#define SCENE_H_INCLUDED
#include<vector>
#include<memory>
#include "../shapes3D/Drawable.h"

class Scene
{
public:
    std::vector<Drawable*> list;
    bool is_sort = true;
public:
    Scene(){};
    ~Scene(){};
    void add(Drawable* dp);
    void remove(Drawable* dp);
    void draw(const Camera& cam);
    void insert_sort();
};


#endif
