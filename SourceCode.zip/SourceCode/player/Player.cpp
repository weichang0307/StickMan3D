#include "player.h"
#include "../data/DataCenter.h"
#include <allegro5/allegro.h>

double Player::state_time() const{
    double time = al_get_time();
    return time - state_start_time;
}
void Player::switch_state(PlayerState s){
    state = s;
    state_start_time = al_get_time();
}
void Player::update(){
    DataCenter *DC = DataCenter::get_instance();

    PlayerState n_state = get_state();
    if(n_state != state && state < PlayerState::ATK1) switch_state(n_state);
    switch (state)
    {
        case PlayerState::STOP : 
            stop();
            break;
        case PlayerState::RUN_F : 
            run_f(); 
            break;
        case PlayerState::RUN_B : 
            run_b(); 
            break;
        case PlayerState::RUN_L : 
            run_l(); 
            break;
        case PlayerState::RUN_R : 
            run_r(); 
            break;
        case PlayerState::ATK1:
            atk1();
            break;
    }
    if(mouseDown){
        double dx = DC->mouse.x - mouseX;
        double dy = DC->mouse.y - mouseY;
        theta -= dx/300;
        phi += dy/300;
        if(phi > 1.5) phi = 1.5;
        if(phi < 0.1) phi = 0.3;
    }
    mouseDown = false;
    if(DC->mouse_state[1]) mouseDown = true;
    mouseX = DC->mouse.x;
    mouseY = DC->mouse.y;
    calculate();
}
PlayerState Player::get_state(){
    if(key_stack.size() == 0) return PlayerState::STOP;
    switch (key_stack[key_stack.size()-1])
    {
        case ALLEGRO_KEY_W:
            return PlayerState::RUN_F;
        case ALLEGRO_KEY_S:
            return PlayerState::RUN_B;
        case ALLEGRO_KEY_D:
            return PlayerState::RUN_R;
        case ALLEGRO_KEY_A:
            return PlayerState::RUN_L;
        case ALLEGRO_KEY_E:
            return PlayerState::ATK1;
    }
    key_stack.pop_back();
    return get_state();
}
void Player::keydown(const int key){
    key_stack.push_back(key);
}
void Player::keyup(const int key){
    auto it = std::find(key_stack.begin(), key_stack.end(), key);
    if(it != key_stack.end()) key_stack.erase(it);
}
void Player::run_f(){
    double time = state_time();
    double speed_factor = 10;
    init_pose();
    l_arm.shoulder[0] = sin(time * speed_factor);
	r_arm.shoulder[0] = -sin(time * speed_factor);
	l_arm.shoulder[1] = 0.2;
	r_arm.shoulder[1] = 0.2;
	l_arm.elbow = sin(time * speed_factor)/2+0.7;
	r_arm.elbow = -sin(time * speed_factor)/2+0.7;
    l_arm.wrist = 1;
	r_arm.wrist = 1;
	l_leg.butt[0] = sin(time * speed_factor)*3/2-0.5;
	r_leg.butt[0] = -sin(time * speed_factor)*3/2-0.5;
	l_leg.knee = -sin(time * speed_factor)+1;
	r_leg.knee = sin(time * speed_factor)+1;
    body.waist = -0.3;

    Vector3 velocity(4 ,0 ,0);
    velocity.rotateZ(theta);
    pos += velocity;
    pos.z = sin(time * speed_factor * 2) * 2 + 1 + l_leg.len[0] + l_leg.len[1];
}
void Player::run_b(){
    double time = state_time();
    double speed_factor = 8;
    init_pose();
    l_arm.shoulder[0] = sin(time * speed_factor)/2;
	r_arm.shoulder[0] = -sin(time * speed_factor)/2;
	l_arm.shoulder[1] = 0.2;
	r_arm.shoulder[1] = 0.2;
	l_arm.elbow = sin(time * speed_factor)/4+0.3;
	r_arm.elbow = -sin(time * speed_factor)/4+0.3;
    l_arm.wrist = 1;
	r_arm.wrist = 1;
	l_leg.butt[0] = sin(time * speed_factor)/2;
	r_leg.butt[0] = -sin(time * speed_factor)/2;
    Vector3 velocity(-2 ,0 ,0);
    velocity.rotateZ(theta);
    pos += velocity;
    feet_on_floor();
}
void Player::run_l(){
    double time = state_time();
    double speed_factor = 8;
    init_pose();
    l_arm.shoulder[0] = -sin(time * speed_factor)/2;
	r_arm.shoulder[0] = sin(time * speed_factor)/2;
	l_arm.shoulder[1] = 0.2;
	r_arm.shoulder[1] = 0.2;
	l_arm.elbow = -sin(time * speed_factor)/4+0.3;
	r_arm.elbow = sin(time * speed_factor)/4+0.3;
    l_arm.wrist = 1;
	r_arm.wrist = 1;
    l_leg.butt[0] = -0.2;
	r_leg.butt[0] = 0.2;
	l_leg.butt[1] = -sin(time * speed_factor)/3;
	r_leg.butt[1] = -sin(time * speed_factor)/3;
    Vector3 velocity(0, 2 ,0);
    velocity.rotateZ(theta);
    pos += velocity;
    feet_on_floor();


}
void Player::run_r(){
    double time = state_time();
    double speed_factor = 8;
    init_pose();
    l_arm.shoulder[0] = sin(time * speed_factor)/2;
	r_arm.shoulder[0] = -sin(time * speed_factor)/2;
	l_arm.shoulder[1] = 0.2;
	r_arm.shoulder[1] = 0.2;
	l_arm.elbow = sin(time * speed_factor)/4+0.3;
	r_arm.elbow = -sin(time * speed_factor)/4+0.3;
    l_arm.wrist = 1;
	r_arm.wrist = 1;
    l_leg.butt[0] = 0.2;
	r_leg.butt[0] = -0.2;
	l_leg.butt[1] = -sin(time * speed_factor)/3;
	r_leg.butt[1] = -sin(time * speed_factor)/3;
    Vector3 velocity(0, -2 ,0);
    velocity.rotateZ(theta);
    pos += velocity;
    feet_on_floor();

}
void Player::stop(){
    init_pose();
    l_arm.shoulder[1] = 0.2;
	r_arm.shoulder[1] = 0.2;
    l_arm.wrist = 1;
	r_arm.wrist = 1;
    feet_on_floor();
}

void Player::atk1(){
    double time = state_time();
    double speed_factor = 8;
    init_pose();
    double a1 = 1.5;
    double a2 = 0;
    double b1 = 0.2;
    double b2 = -1;
    double t1 = 0.1;
    double t2 = 0.2;
    double t3 = 0.7;
    l_arm.shoulder[1] = 1;
	r_arm.shoulder[1] = 1;
    if(time < t1){
        l_arm.shoulder[0] = a1;
	    r_arm.shoulder[0] = a1;
        l_arm.elbow = a1;
	    r_arm.elbow = a1;
        l_leg.butt[0] = -b1 * time / t1;
        r_leg.butt[0] = b1 * time / t1;
        r_leg.knee = 0;
        body.waist = b1 * time / t1;
    }
    if(time >= t1 && time < t2){
        l_arm.shoulder[0] = a1 + (a2-a1) * (time - t1) / (t2 -t1);
	    r_arm.shoulder[0] = a1 + (a2-a1) * (time - t1) / (t2 -t1);
        l_arm.elbow = a1 + (a2-a1) * (time - t1) / (t2 -t1);
	    r_arm.elbow = a1 + (a2-a1) * (time - t1) / (t2 -t1);
        body.waist = b1 + (b2-b1) * (time - t1) / (t2 -t1);
        l_leg.butt[0] = - b1 - (b2-b1) * (time - t1) / (t2 -t1);
        r_leg.butt[0] =  b1 + (b2-b1) * (time - t1) / (t2 -t1);
        r_leg.knee = - 0 - (b2*2-0) * (time - t1) / (t2 -t1);
        Vector3 velocity(50 ,0 ,0);
        velocity.rotateZ(theta);
        pos += velocity;
    }
    if(time >= t2){
        l_arm.shoulder[1] = 0.8 * (t3 - time) / (t3 -t2) + 0.2;
	    r_arm.shoulder[1] = 0.8 * (t3 - time) / (t3 -t2) + 0.2;
        body.waist = b2 * (t3 - time) / (t3 -t2);
        l_leg.butt[0] = -b2 * (t3 - time) / (t3 -t2);
        r_leg.butt[0] = b2 * (t3 - time) / (t3 -t2);
        r_leg.knee = -b2 * 2 * (t3 - time) / (t3 -t2);
        l_arm.wrist = 1 - 1 * (t3 - time) / (t3 -t2);
	    r_arm.wrist = 1 - 1 * (t3 - time) / (t3 -t2);
        Vector3 velocity(1 ,0 ,0);
        velocity.rotateZ(theta);
        pos += velocity;
    }
    if(time >= t3){
	    switch_state(PlayerState::TEMP);
    }
    feet_on_floor();
    
}