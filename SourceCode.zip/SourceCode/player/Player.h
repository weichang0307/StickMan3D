#ifndef PLAYER_H_INCLUDED
#define PLAYER_H_INCLUDED

#include "../stickman/Stickman.h"
#include <allegro5/allegro.h>
#include <vector>
#include <algorithm>
#include <stdio.h>

enum class PlayerState {
    TEMP,
    STOP,
    RUN_F,
    RUN_B,
    RUN_L,
    RUN_R,
    ATK1
};


class Player : public Stickman
{
public:
    PlayerState state = PlayerState::TEMP;
    int HP = 50;
    int MAX_HP = 50;
    int ir = 255, ig = 0, ib = 0;
    std::vector<int> key_stack;
    double mouseX, mouseY;
    bool mouseDown = false;
    bool attack = false;
    double state_start_time;
public:
    Player() : Stickman() {};
    ~Player() {};
    void update();
    PlayerState get_state();
    void keydown(const int key);
    void keyup(const int key);
    void switch_state(PlayerState s);
    double state_time() const;
    void run_f();
    void run_b();
    void run_l();
    void run_r();
    void atk1();
    void stop();
};








#endif