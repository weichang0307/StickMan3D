#ifndef GAME_H_INCLUDED
#define GAME_H_INCLUDED

#include <allegro5/allegro.h>
#include "UI.h"
#include "3D/Scene.h"
#include "shapes3D/Stick.h"
#include "stickman/Stickman.h"
#include "player/Player.h"
#include <vector>
#include <memory>

/**
 * @brief Main class that runs the whole game.
 * @details All game procedures must be processed through this class.
*/
class Game
{
public:
	void execute();
public:
	Game();
	~Game();
	void game_init();
	bool game_update();
	void game_keydown();
	void game_keyup();
	void game_draw();
private:
	/**
	 * @brief States of the game process in game_update.
	 * @see Game::game_update()
	*/
	enum class STATE {
		START, 
		PAUSE,
		PREPARE,
		END
	};
	STATE state;
	ALLEGRO_EVENT event;
	/*test*/
	Scene scene;
    std::shared_ptr<Drawable> s1;
	std::vector<std::shared_ptr<Drawable>> ss;

	ALLEGRO_BITMAP *game_icon;
private:
	ALLEGRO_DISPLAY *display;
	ALLEGRO_TIMER *timer;
	ALLEGRO_EVENT_QUEUE *event_queue;
	UI *ui;
};

#endif
