#include "Stickman.h"
#include <math.h>

void Stickman::calculate(){
    for(auto &part_ptr : parts_ptr){
        part_ptr->calculate();
    }
    head.pos.set(0, 0, head.radius * 3 / 2);
    l_arm.rotateY(-body.waist);
    r_arm.rotateY(-body.waist);
    head.pos.rotateY(-body.waist);
    l_arm.translate(body.pts[4].pos);
    r_arm.translate(body.pts[5].pos);
    l_leg.translate(body.pts[2].pos);
    r_leg.translate(body.pts[3].pos);
    head.pos += body.pts[1].pos;
    
    for(auto &part_ptr : parts_ptr){
        part_ptr->rotateZ(theta);
        part_ptr->translate(pos);
    }
    head.pos.rotateZ(theta);
    head.pos += pos;
    shadow.pos = pos;
    shadow.pos.z = 0;

}
void Stickman::feet_on_floor(){
    calculate();
    pos.z = -std::min(l_leg.pts[2].pos.z, r_leg.pts[2].pos.z);
}

void Stickman::add_to_scene(Scene &scene, Scene &floor){
    for(auto &part_ptr : parts_ptr){
        part_ptr->add_to_scene(scene);
    }
    scene.add(&head);
    floor.add(&shadow);
}

void Stickman::init_pose(){
    l_arm.shoulder[0] = 0;
	r_arm.shoulder[0] = 0;
	l_arm.shoulder[1] = 0;
	r_arm.shoulder[1] = 0;
	l_arm.elbow = 0;
	r_arm.elbow = 0;
    l_arm.wrist = 0;
    r_arm.wrist = 0;
	l_leg.butt[0] = 0;
	r_leg.butt[0] = 0;
	l_leg.butt[1] = 0;
	r_leg.butt[1] = 0;
	l_leg.knee = 0;
	r_leg.knee = 0;
    body.waist = 0;
    pos.z = 0;
}