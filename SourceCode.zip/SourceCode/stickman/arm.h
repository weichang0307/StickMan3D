#ifndef ARM_H_INCLUDED
#define ARM_H_INCLUDED

#include "../shapes3D/Point3D.h"
#include "../shapes3D/Stick.h"
#include "../shapes3D/Vector3.h"
#include <vector>
#include "part.h"
#include <iostream>

class Arm : public Part
{
public:
    double shoulder[2] = {0, 0};
    double elbow = 0;
    double wrist = 0;
    double len[4] = {20,20,10,60};
    bool left = false;
public:
    Arm(const bool &left_){
        left = left_;
        for(int i=0;i<5;i++)pts.push_back(Point3D(0, 0, 0));
        elements.push_back(std::make_unique<Stick>(pts[0], pts[1], r, g, b, radius));
        elements.push_back(std::make_unique<Stick>(pts[1], pts[2], r, g, b, radius));
        elements.push_back(std::make_unique<Stick>(pts[2], pts[3], 100, 100, 100, radius*3/4));
        elements.push_back(std::make_unique<Stick>(pts[3], pts[4], 255, 255, 255, radius*3/4));
    }
    ~Arm(){};
    void calculate(){
        pts[0].pos.set(0, 0, 0);
        pts[1].pos.set(0, 0, -len[0]);
        pts[2].pos.set(0, 0, -len[1]);
        pts[3].pos.set(0, 0, -len[2]);
        pts[4].pos.set(0, 0, -len[3]);
        pts[1].pos.rotateY(-shoulder[0]);
        pts[2].pos.rotateY(-shoulder[0]-elbow);
        pts[3].pos.rotateY(-shoulder[0]-elbow-wrist);
        pts[4].pos.rotateY(-shoulder[0]-elbow-wrist);
        pts[2].pos += pts[1].pos;
        pts[3].pos += pts[2].pos;
        pts[4].pos += pts[3].pos;
        for (Point3D &pt : pts){
            if(left) pt.pos.rotateX(shoulder[1]);
            else pt.pos.rotateX(-shoulder[1]);
        }        
    }
    void rotateY(const double &theta){
        for(Point3D &pt : pts){
            pt.pos.rotateY(theta);
        }
    }
    virtual void set_color(int r_, int g_, int b_){
        r = r_;
        g = g_;
        b = b_;
        int i=0;
        for(auto &elm : elements){
            if(i++ >= 2) break;
            elm->set_color(r_, g_, b_);
        }
    }
};

#endif
