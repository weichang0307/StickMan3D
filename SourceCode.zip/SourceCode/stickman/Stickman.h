#ifndef STICKMAN_H_INCLUDED
#define STICKMAN_H_INCLUDED

#include "../shapes3D/Point3D.h"
#include "../shapes3D/Shadow.h"
#include "../shapes3D/Stick.h"
#include "../3D/Scene.h"
#include "arm.h"
#include "leg.h"
#include "body.h"
#include "part.h"
#include <vector>
#include <memory>
#include <iostream>

class Stickman
{
public:
    Vector3 pos;
    double theta = 0, phi = 0;
    int r, g, b;
    Body body; 
    Arm l_arm{true}, r_arm{false};
    Leg l_leg{true}, r_leg{false};
    Point3D head;
    Shadow shadow;
    std::vector<Part*> parts_ptr;
public:
    Stickman(){
        parts_ptr.push_back(&body);
        parts_ptr.push_back(&l_arm);
        parts_ptr.push_back(&r_arm);
        parts_ptr.push_back(&l_leg);
        parts_ptr.push_back(&r_leg);
        head.radius = 15;
        shadow.radius = 25;
        shadow.set_color(40, 40, 40);
    };
    ~Stickman(){};
    void calculate();
    void feet_on_floor();
    void init_pose();
    void add_to_scene(Scene &scene, Scene &floor);
    void set_color(int r_, int g_, int b_){
        for(auto ppt : parts_ptr){
            ppt->set_color(r_, g_, b_);
            r = r_;
            g = g_;
            b = b_;
        }
        head.set_color(r_, g_, b_);
    }
};
#endif