#ifndef PART_H_INCLUDED
#define PART_H_INCLUDED


#include "../shapes3D/Point3D.h"
#include "../shapes3D/Stick.h"
#include "../shapes3D/Vector3.h"
#include "../3D/Scene.h"
#include <vector>
#include <iostream>


class Part
{
public:
    std::vector<Point3D> pts;
    std::vector<std::unique_ptr<Drawable>> elements; 
    int r = 255, g = 0, b = 0;
    int radius = 5;
public:
    Part(){};
    ~Part(){};
    virtual void calculate() = 0;
    void add_to_scene(Scene &s){
        for(auto &element : elements){
            s.add(&(*element));
        }
    }
    virtual void translate(const Vector3 &v){
        for(Point3D &pt : pts){
            pt.pos += v;
        }
    }
    virtual void rotateZ(const double &theta){
        for(Point3D &pt : pts){
            pt.pos.rotateZ(theta);
        }
    }
    virtual void set_color(int r_, int g_, int b_){
        r = r_;
        g = g_;
        b = b_;
        for(auto &elm : elements){
            elm->set_color(r_, g_, b_);
        }
    }
};

#endif
