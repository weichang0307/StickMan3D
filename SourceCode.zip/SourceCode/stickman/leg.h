#ifndef LEG_H_INCLUDED
#define LEG_H_INCLUDED


#include "../shapes3D/Point3D.h"
#include "../shapes3D/Stick.h"
#include "../shapes3D/Vector3.h"
#include <vector>
#include "part.h"


class Leg : public Part
{
public:
    double butt[2] = {0, 0};
    double knee = 0;
    double len[2] = {30,30};
    bool left = false;
public:
    Leg(const bool &left_){
        left = left_;
        for(int i=0;i<3;i++)pts.push_back(Point3D(0, 0, 0));
        elements.push_back(std::make_unique<Stick>(pts[0], pts[1]));
        elements.push_back(std::make_unique<Stick>(pts[1], pts[2]));
    };
    ~Leg(){};
    void calculate(){
        pts[0].pos.set(0, 0, 0);
        pts[1].pos.set(0, 0, -len[0]);
        pts[2].pos.set(0, 0, -len[1]);
        pts[1].pos.rotateY(butt[0]);
        pts[2].pos.rotateY(butt[0]+knee);
        pts[2].pos += pts[1].pos;
        for (Point3D& pt : pts){
            if(left) pt.pos.rotateX(butt[1]);
            else pt.pos.rotateX(-butt[1]);
        }     
    }
    
};
#endif