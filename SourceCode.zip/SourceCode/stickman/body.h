#ifndef BODY_H_INCLUDED
#define BODY_H_INCLUDED


#include "../shapes3D/Point3D.h"
#include "../shapes3D/Stick.h"
#include "../shapes3D/Vector3.h"
#include <vector>
#include "part.h"

class Body : public Part
{
public:
    double waist = 0;
    double len[3] = {50, 20, 30};
public:
    Body(){
        for(int i=0;i<6;i++)pts.push_back(Point3D(0, 0, 0));
        elements.push_back(std::make_unique<Stick>(pts[0], pts[1]));
        elements.push_back(std::make_unique<Stick>(pts[2], pts[3]));
        elements.push_back(std::make_unique<Stick>(pts[4], pts[5]));
    };
    ~Body(){};
    void calculate(){
        pts[0].pos.set(0, 0, 0);
        pts[1].pos.set(0, 0, len[0]);
        pts[2].pos.set(0, len[1] / 2, 0);
        pts[3].pos.set(0, -len[1] / 2, 0);
        pts[4].pos.set(0, len[2] / 2, len[0]);
        pts[5].pos.set(0, -len[2] / 2, len[0]);
        for (Point3D &pt : pts){
            pt.pos.rotateY(-waist);
        }     
    }
    
};
#endif