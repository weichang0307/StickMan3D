#include "EnemyA.h"
#include "../data/DataCenter.h"
#include "../data/PlayerCenter.h"
#include <allegro5/allegro.h>


void EnemyA::update(){
    DataCenter *DC = DataCenter::get_instance();
    Enemy::update();
    switch (state)
    {
        case EnemyState::STOP : 
            stop();
            break;
        case EnemyState::RUN : 
            run(); 
            break;
        case EnemyState::ATTACK : 
            attack(); 
            break;
    }
    calculate();
}
EnemyState EnemyA::get_state(){
	PlayerCenter *PC = PlayerCenter::get_instance();
    if((PC->player.pos - pos).abs1() < 100) return::EnemyState::ATTACK;
    return EnemyState::RUN;
} 
void EnemyA::run(){
	PlayerCenter *PC = PlayerCenter::get_instance();
    double time = state_time();
    double speed_factor = 10;
    init_pose();
    theta = (PC->player.pos - pos).angleXY();
    l_arm.shoulder[0] = sin(time * speed_factor);
	r_arm.shoulder[0] = -sin(time * speed_factor);
	l_arm.shoulder[1] = 0.2;
	r_arm.shoulder[1] = 0.2;
	l_arm.elbow = sin(time * speed_factor)/2+0.7;
	r_arm.elbow = -sin(time * speed_factor)/2+0.7;
    l_arm.wrist = 1;
	r_arm.wrist = 1;
	l_leg.butt[0] = sin(time * speed_factor)*3/2-0.5;
	r_leg.butt[0] = -sin(time * speed_factor)*3/2-0.5;
	l_leg.knee = -sin(time * speed_factor)+1;
	r_leg.knee = sin(time * speed_factor)+1;
    body.waist = -0.3;

    Vector3 velocity(2 ,0 ,0);
    velocity.rotateZ(theta);
    pos += velocity;
    pos.z = sin(time * speed_factor * 2) * 2 + 1 + l_leg.len[0] + l_leg.len[1];
}
void EnemyA::stop(){
    init_pose();
    l_arm.shoulder[1] = 0.2;
	r_arm.shoulder[1] = 0.2;
    l_arm.wrist = 1;
	r_arm.wrist = 1;
    pos.z = l_leg.len[0] + l_leg.len[1];
}
void EnemyA::attack(){
	PlayerCenter *PC = PlayerCenter::get_instance();
    double time = state_time();
    double speed_factor = 8;
    init_pose();
    double a1 = 1.5;
    double a2 = 0;
    double b1 = 0.4;
    double b2 = -0.4;
    double t1 = 0.3;
    double t2 = 0.45;
    double t3 = 0.8;
    l_arm.shoulder[1] = 1;
	r_arm.shoulder[1] = 1;
    if(time < t1){
        l_arm.shoulder[0] = a1;
	    r_arm.shoulder[0] = a1;
        l_arm.elbow = a1;
	    r_arm.elbow = a1;
        l_leg.butt[0] = -b1 * time / t1;
        r_leg.butt[0] = b1 * time / t1;
        r_leg.knee = 0;
        body.waist = b1 * time / t1;
    }
    if(time >= t1 && time < t2){
        Vector3 enm_to_player = PC->player.pos - pos;
        if(enm_to_player.abs1() < 300){
            if (abs(acos(cos(enm_to_player.angleXY() - theta))) < 1){
                PC->player.HP--;
            }
        }
        l_arm.shoulder[0] = a1 + (a2-a1) * (time - t1) / (t2 -t1);
	    r_arm.shoulder[0] = a1 + (a2-a1) * (time - t1) / (t2 -t1);
        l_arm.elbow = a1 + (a2-a1) * (time - t1) / (t2 -t1);
	    r_arm.elbow = a1 + (a2-a1) * (time - t1) / (t2 -t1);
        body.waist = b1 + (b2-b1) * (time - t1) / (t2 -t1);
        l_leg.butt[0] = - b1 - (b2-b1) * (time - t1) / (t2 -t1);
        r_leg.butt[0] =  b1 + (b2-b1) * (time - t1) / (t2 -t1);
        r_leg.knee = - 0 - (b2*2-0) * (time - t1) / (t2 -t1);
        Vector3 velocity(4 ,0 ,0);
        velocity.rotateZ(theta);
        pos += velocity;
    }
    if(time >= t2){
        l_arm.shoulder[1] = 0.8 * (t3 - time) / (t3 -t2) + 0.2;
	    r_arm.shoulder[1] = 0.8 * (t3 - time) / (t3 -t2) + 0.2;
        body.waist = b2 * (t3 - time) / (t3 -t2);
        l_leg.butt[0] = -b2 * (t3 - time) / (t3 -t2);
        r_leg.butt[0] = b2 * (t3 - time) / (t3 -t2);
        r_leg.knee = -b2 * 2 * (t3 - time) / (t3 -t2);
        l_arm.wrist = 1 - 1 * (t3 - time) / (t3 -t2);
	    r_arm.wrist = 1 - 1 * (t3 - time) / (t3 -t2);
    }
    if(time >= t3){
        theta = (PC->player.pos - pos).angleXY();
	    switch_state(EnemyState::TEMP);
    }
    feet_on_floor();
    
}