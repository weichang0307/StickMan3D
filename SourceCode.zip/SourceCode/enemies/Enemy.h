#ifndef ENEMY_H_INCLUDED
#define ENEMY_H_INCLUDED

#include "../stickman/Stickman.h"
#include <allegro5/allegro.h>
#include <vector>
#include <algorithm>
#include <stdio.h>
enum class EnemyState {
    TEMP,
    STOP,
    RUN,
    ATTACK
};

class Enemy : public Stickman
{
public:
    EnemyState state;
    double state_start_time;
public:
    Enemy() : Stickman() {};
    ~Enemy() {};
    virtual void update() = 0;
    virtual EnemyState get_state() = 0;
    virtual void run() = 0;
    virtual void stop() = 0;
    virtual void attack() = 0;
    void switch_state(EnemyState s){
        state = s;
        state_start_time = al_get_time();
    }
    double state_time() const{
        double time = al_get_time();
        return time - state_start_time;
    }
};








#endif