#ifndef ENEMYA_H_INCLUDED
#define ENEMYA_H_INCLUDED

#include "../stickman/Stickman.h"
#include "Enemy.h"
#include <allegro5/allegro.h>
#include <vector>
#include <algorithm>
#include <stdio.h>

class EnemyA : public Enemy
{


public:
    EnemyA() : Enemy(200, 0, 200) {};
    ~EnemyA() {};
    void update() override;
    EnemyState get_state() override;
    void run() override;
    void stop() override;
    void attack() override;
};








#endif