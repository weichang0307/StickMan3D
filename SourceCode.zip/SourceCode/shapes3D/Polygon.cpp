#include "Polygon.h"
#include "Vector3.h"
#include "Point3D.h"

Vector3 Polygon::get_center() const{
    Vector3 c(0,0,0);
    for(auto &pt : pts){
        c += pt->pos;
    }
    c = c / pts.size();
    return c;
}
double Polygon::get_px() const{
    double c = 0;
    for(auto &pt : pts){
        c += pt->px;
    }
    c = c / pts.size();
    return c;
}
double Polygon::get_py() const{
    double c = 0;
    for(auto &pt : pts){
        c += pt->py;
    }
    c = c / pts.size();
    return c;
}
double Polygon::get_pz() const{    
    double c = 0;
    for(auto &pt : pts){
        c += pt->pz;
    }
    c = c / pts.size();
    return c;
}