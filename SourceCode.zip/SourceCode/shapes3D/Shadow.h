#ifndef SHADOW_H_INCLUDED
#define SHADOW_H_INCLUDED

#include "Shape3D.h"
#include "Drawable.h"
#include "Point3D.h"
#include "Vector3.h"
#include <cmath>

class Shadow : public Point3D
{
    public:
    Shadow() : Point3D(){}
    Shadow(Vector3 &v) : Point3D(v){}
    Shadow(const double &x, const double &y, const double &z) : Point3D(x, y, z){}
    double phi, alpha = 0.5;
    void draw() const;
	void project(const Camera &cam);
};



#endif
