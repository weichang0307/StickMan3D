#ifndef SHADOW_H_INCLUDED
#define SHADOW_H_INCLUDED

#include "Shape3D.h"
#include "Drawable.h"
#include "Point3D.h"
#include "Vector3.h"
#include <cmath>

class Shadow : public Point3D
{
    public:
	const Shape3DType getType() const { return Shape3DType::SHADOW;}
	void draw() const;
    public:
    Shadow() : Point3D(){}
    Shadow(Vector3 &v) : Point3D(v){}
    Shadow(const double &x, const double &y, const double &z) : Point3D(x, y, z){}
    double phi = 0, alpha = 0.5;
};



#endif
