#ifndef SHAPE3D_H_INCLUDED
#define SHAPE3D_H_INCLUDED

#include "Vector3.h"

enum class Shape3DType {
	POINT3D,
	PLANE,
	STICK,
	POLYGON,
	SHADOW,
	ASH
};

/**
 * @brief Base shape3D class.
 * @details Base shape3D class.
 * @see Shape3D.cpp
*/
class Shape3D
{
public:
	virtual const Shape3DType getType() const = 0;
	virtual ~Shape3D() {};
};

#endif
