#include <cmath>
#include "Vector3.h"
#include "../Utils.h"

Vector3 operator+(const Vector3 &v1, const Vector3 &v2) {
    return Vector3(v1.x + v2.x, v1.y + v2.y, v1.z + v2.z);
}

Vector3 operator-(const Vector3 &v1, const Vector3 &v2) {
    return Vector3(v1.x - v2.x, v1.y - v2.y, v1.z - v2.z);
}

Vector3 operator*(const Vector3 &v1, const double& alpha) {
    return Vector3(v1.x * alpha, v1.y * alpha, v1.z * alpha);
}

Vector3 operator/(const Vector3 &v1, const double& alpha) {
    if (alpha == 0) {
        	GAME_ASSERT(operator/, "divided by zero");
            return v1;
    }
    return Vector3(v1.x / alpha, v1.y / alpha, v1.z / alpha);
}
Vector3& Vector3::operator+=(const Vector3& v) {
    x += v.x;
    y += v.y;
    z += v.z;
    return *this;
}

Vector3& Vector3::operator-=(const Vector3& v) {
    x -= v.x;
    y -= v.y;
    z -= v.z;
    return *this;
}

Vector3 cross(const Vector3 &v1, const Vector3 &v2) {
    return Vector3(
        v1.y * v2.z - v1.z * v2.y,
        v1.z * v2.x - v1.x * v2.z,
        v1.x * v2.y - v1.y * v2.x
    );
}
double dot(const Vector3 &v1, const Vector3 &v2) {
    return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
}

// Rotate around the X-axis
void Vector3::rotateX(const double& theta) {
    double cosTheta = std::cos(theta);
    double sinTheta = std::sin(theta);
    double newY = y * cosTheta - z * sinTheta;
    double newZ = y * sinTheta + z * cosTheta;
    y = newY;
    z = newZ;
}

// Rotate around the Y-axis
void Vector3::rotateY(const double& theta) {
    double cosTheta = std::cos(theta);
    double sinTheta = std::sin(theta);
    double newX = x * cosTheta + z * sinTheta;
    double newZ = -x * sinTheta + z * cosTheta;
    x = newX;
    z = newZ;
}

// Rotate around the Z-axis
void Vector3::rotateZ(const double& theta) {
    double cosTheta = std::cos(theta);
    double sinTheta = std::sin(theta);
    double newX = x * cosTheta - y * sinTheta;
    double newY = x * sinTheta + y * cosTheta;
    x = newX;
    y = newY;
}
