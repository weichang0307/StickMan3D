#ifndef POLYGON_H_INCLUDED
#define POLYGON_H_INCLUDED

#include "Shape3D.h"
#include "Drawable.h"
#include "Vector3.h"
#include <cmath>
#include <vector>
#include <memory>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
/**
 * @see Shape.cpp
*/
class Polygon : public Drawable
{
public:
	const Shape3DType getType() const { return Shape3DType::POINT3D;}
	void draw() const;
	void project(const Camera &cam);
	~Polygon() {};
	
public:
	Polygon() : pos(Vector3(0,0,0)){}
	Polygon(const Vector3 &v) : pos(v) {}
	Polygon(const double& x, const double& y, const double& z) : pos(Vector3(x,y,z)) {}
	double get_px() const;
	double get_py() const;
	double get_pz() const;
	Vector3 get_center() const;
	void add(std::shared_ptr<Point3D> pt){
		pts.push_back(pt);
		vtx.push_back(pt->px);
		vtx.push_back(pt->py);
	};
	Vector3 pos;
	std::vector<std::shared_ptr<Point3D>> pts;
	std::vector<float> vtx;
};


#endif
