#ifndef Vector3_H_INCLUDED
#define Vector3_H_INCLUDED

#include <cmath>
#include <iostream>

#ifndef PI
#define PI 3.14159265358979323846
#endif
/**
 * @brief Three dimension vector with x, y, z
*/

class Vector3
{
public:
    double x, y, z;
public:
    Vector3() : x(0), y(0), z(0){};
    Vector3(const double& x, const double& y, const double& z) : x(x), y(y), z(z){};
    ~Vector3(){};
    void set(const double& x_, const double& y_, const double& z_){x = x_; y = y_; z = z_;};
    double abs2() const {return x * x + y * y + z * z;}
    double abs1() const {return sqrt((*this).abs2());}
    double angleXY() const {return atan2(y, x);}
    Vector3 unit() const {return (*this)/(this->abs1());}
    void show() const {std::cout<<x<<" "<<y<<" "<<z<<std::endl;}
    void rotateX(const double& theta);
    void rotateY(const double& theta);
    void rotateZ(const double& theta);
    friend Vector3 operator+(const Vector3 &v1, const Vector3 &v2);
    friend Vector3 operator-(const Vector3 &v1, const Vector3 &v2);
    friend Vector3 operator*(const Vector3 &v1, const double& alpha);
    friend Vector3 operator/(const Vector3 &v1, const double& alpha);
    Vector3& operator+=(const Vector3& v);
    Vector3& operator-=(const Vector3& v);
    friend Vector3 cross(const Vector3 &v1, const Vector3 &v2);
    friend double dot(const Vector3 &v1, const Vector3 &v2);
};


#endif