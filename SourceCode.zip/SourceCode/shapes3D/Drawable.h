#ifndef DRAWABLE_H_INCLUDED
#define DRAWABLE_H_INCLUDED


#include "Shape3D.h"



/**
 * @brief Drawable shape3D class.
 * @details Drawable shape3D class.
*/
class Camera;
class Point3D;
class Stick;

class Drawable : Shape3D
{
public:
	virtual const Shape3DType getType() const = 0;
	virtual void draw() const=0;
	virtual void project(const Camera &cam)=0;
	virtual bool closer(const Drawable &d) const{
		return this->get_pz() <= d.get_pz();
	}
	virtual void set_color(int r_, int g_, int b_){r = r_; g = g_; b = b_;}
	virtual double get_px() const{}
	virtual double get_py() const{}
	virtual double get_pz() const{}
	virtual ~Drawable() {};
	int r = 255 ,g = 0 ,b = 0;
};

#endif