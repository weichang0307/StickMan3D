#ifndef POINT3D_H_INCLUDED
#define POINT3D_H_INCLUDED

#include "Shape3D.h"
#include "Drawable.h"
#include "Vector3.h"
#include <cmath>

/**
 * @see Shape.cpp
*/
class Point3D : public Drawable
{
public:
	const Shape3DType getType() const { return Shape3DType::POINT3D;}
	void draw() const;
	void project(const Camera &cam);
	~Point3D() {};
	
public:
	Point3D() : pos(Vector3(0,0,0)){}
	Point3D(const double& x, const double& y, const double& z) : pos(Vector3(x,y,z)) {}
	Point3D(const Vector3 &v) : pos(v) {}
	static double dist2(const Point3D &p1, const Point3D &p2) {
		return (p1.pos - p2.pos).abs2();
	}
	static double dist(const Point3D &p1, const Point3D &p2) {
		return std::sqrt(dist2(p1, p2));
	}
	double get_px() const{return px;}
	double get_py() const{return py;}
	double get_pz() const{return pz;}
	Vector3 pos;
	bool fill = false;
	double px = 0, py = 0, pz = 0;
	double radius = 5, pr = 0;
};

#endif
