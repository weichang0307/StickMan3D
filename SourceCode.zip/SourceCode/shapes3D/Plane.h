#ifndef PLANE_H_INCLUDED
#define PLANE_H_INCLUDED

#include "Shape3D.h"
#include "Vector3.h"
#include <cmath>

/**
 * @see Shape.cpp
*/
class Plane : public Shape3D
{
public:
	const Shape3DType getType() const { return Shape3DType::PLANE; }
	~Plane(){};
public:
	Plane() : pos(Vector3(0, 0, 0)), normal_vector(Vector3(1 ,0 ,0)) {}
	Plane(Vector3 normal_vector) : pos(Vector3(0, 0, 0)), normal_vector(normal_vector) {}
	Plane(Vector3 pos, Vector3 normal_vector) : pos(pos), normal_vector(normal_vector) {}
	Vector3 normal_vector, pos;
	
};

#endif
