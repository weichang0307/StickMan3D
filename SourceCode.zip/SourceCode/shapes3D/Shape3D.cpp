
#include "Point3D.h"
#include "../Utils.h"
#include <algorithm>

using namespace std;

/**
 * @file Shape.cpp
 * @brief All functions and implementations are defined here.
*/


