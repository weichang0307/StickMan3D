#ifndef STICK_H_INCLUDED
#define STICK_H_INCLUDED

#include "Shape3D.h"
#include "Point3D.h"
#include "Drawable.h"
#include <cmath>

/**
 * @brief 3D stick with two point as end
*/
class Stick : public Drawable
{
public:
	const Shape3DType getType() const { return Shape3DType::STICK;}
	void draw() const;
	void project(const Camera &cam);
	~Stick() {};
	
public:
	Stick(Point3D &p1, Point3D &p2) : p1(p1), p2(p2){}
	Stick(Point3D &p1, Point3D &p2, int r, int g, int b, double radius) : p1(p1), p2(p2), radius(radius){
		set_color(r, g, b);
	}
	double get_px() const{return (p1.px + p2.px) / 2;}
	double get_py() const{return (p1.py + p2.py) / 2;}
	double get_pz() const{return (p1.pz + p2.pz) / 2;}
	Point3D &p1, &p2;
    double radius = 5, pr;

};

#endif
