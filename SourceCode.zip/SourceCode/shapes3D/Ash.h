#ifndef ASH_H_INCLUDED
#define ASH_H_INCLUDED

#include "Shape3D.h"
#include "Drawable.h"
#include "Vector3.h"
#include <cmath>
#include <vector>
#include <memory>
#include <tuple>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <random>
/**
 * @see Shape.cpp
*/
class Ash : public Point3D
{
public:
	const Shape3DType getType() const { return Shape3DType::ASH;}
	void draw() const;
	Ash(const Vector3 &v, double radius_, Vector3 base_, double alpha_) : Point3D(v){
		radius = radius_;
		base = base_;
		alpha = alpha_;
	}
	~Ash() {};
public:
	void init(){
		r = g = b = 255;
		alpha = 0.5;
		fade = 0.05;
	}
	void update(){
		alpha *= 1 - fade;
		pos = base + (pos - base) * (1 + fade);
	}
	double alpha, fade;
	Vector3 base;
};


#endif
