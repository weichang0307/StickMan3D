#include "Point3D.h"
#include "Stick.h"
#include "Shadow.h"
#include "Polygon.h"
#include "Ash.h"
#include "../3D/Camera.h"
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <iostream>
#include <tuple>

void Point3D::draw() const{
    if(pz <= 0)return;
    al_draw_circle(px, py, pr, al_map_rgb(r, g, b), pr/4);
}
void Point3D::project(const Camera &cam){
    auto [px_, py_, pz_, ps_, success] = cam.project(pos);
    if(!success) return;
    px = px_; py = py_; pz = pz_;
    pr = radius * ps_;
}
void Stick::draw() const{
    if(p1.pz<=0 || p2.pz<=0)return;
    al_draw_line(p1.px, p1.py, p2.px, p2.py, al_map_rgb(r, g, b), pr);
}
void Stick::project(const Camera &cam){
    p1.project(cam);
    p2.project(cam);
    pr = radius * cam.scale / abs(get_pz());
}


void Shadow::draw() const{
    if(pz <= 0)return;
    al_draw_filled_ellipse(px, py, pr, pr * abs(sin(phi)), al_map_rgba(r, g, b, alpha));
}


void Polygon::draw() const{
    if(!too_far)al_draw_filled_polygon(vtx.data(), vtx.size() / 2, al_map_rgb(r, g, b));
}
void Polygon::project(const Camera &cam){
    if((cam.target - pos).abs1() > max_dis){
        too_far = true;
        return;
    } 
    too_far = false;
    for(int i=0; i<pts.size(); i++){
        pts[i]->pos += pos;
        pts[i]->project(cam);
        pts[i]->pos -= pos; 
        vtx[i * 2] = pts[i]->px;
        vtx[i * 2 + 1] = pts[i]->py;
    }
}
void Ash::draw() const{
    al_draw_filled_circle(px, py, pr, al_map_rgba(r * alpha, g * alpha, b * alpha, 1));
}






