#include "Point3D.h"
#include "Stick.h"
#include "Shadow.h"
#include "Polygon.h"
#include "../3D/Camera.h"
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <iostream>
#include <tuple>

void Point3D::draw() const{
    if(pz <= 0)return;
    al_draw_circle(px, py, pr, al_map_rgb(r, g, b), pr/4);
}
void Point3D::project(const Camera &cam){
    Vector3 camToPoint = pos - cam.position();
    pz = dot(cam.direction(), camToPoint);
    if(pz == 0)return;
    pz = pz / abs(pz) * camToPoint.abs1();
    camToPoint.rotateZ(-cam.theta);
    camToPoint.rotateY(-cam.phi);
    Vector3 direction = camToPoint.unit();
    px = - cam.scale * direction.y;
    py = - cam.scale * direction.z;
    if(pz<0){
        double scale = cam.scale / sqrt(px * px + py * py);
        px *= scale;
        py *= scale;
    }
    pr = radius * cam.scale / abs(pz);
    px += cam.centerx;
    py += cam.centery;
}
void Stick::draw() const{
    if(p1.pz<=0 || p2.pz<=0)return;
    al_draw_line(p1.px, p1.py, p2.px, p2.py, al_map_rgb(r, g, b), pr);
}
void Stick::project(const Camera &cam){
    p1.project(cam);
    p2.project(cam);
    pr = radius * cam.scale / abs(get_pz());
}


void Shadow::draw() const{
    if(pz <= 0)return;
    al_draw_filled_ellipse(px, py, pr, pr * abs(sin(phi)), al_map_rgba(r, g, b, alpha));
}

void Shadow::project(const Camera &cam){
    Point3D::project(cam);
    phi = cam.phi;
}

void Polygon::draw() const{
    al_draw_filled_polygon(vtx.data(), vtx.size() / 2, al_map_rgb(r, g, b));
}
void Polygon::project(const Camera &cam){
    for(int i=0; i<pts.size(); i++){
        pts[i]->pos += pos;
        pts[i]->project(cam);
        pts[i]->pos -= pos;
        vtx[i * 2] = pts[i]->px;
        vtx[i * 2 + 1] = pts[i]->py;
    }
}
Vector3 Polygon::get_center() const{
    Vector3 c(0,0,0);
    for(auto &pt : pts){
        c += pt->pos;
    }
    c = c / pts.size();
    return c;
}
double Polygon::get_px() const{
    double c = 0;
    for(auto &pt : pts){
        c += pt->px;
    }
    c = c / pts.size();
    return c;
}
double Polygon::get_py() const{
    double c = 0;
    for(auto &pt : pts){
        c += pt->py;
    }
    c = c / pts.size();
    return c;
}
double Polygon::get_pz() const{
    double c = 0;
    for(auto &pt : pts){
        c += pt->pz;
    }
    c = c / pts.size();
    return c;
}



