#include "Game.h"
#include "Utils.h"
#include "data/DataCenter.h"
#include "data/SoundCenter.h"
#include "data/ImageCenter.h"
#include "data/FontCenter.h"
#include "data/EnemyCenter.h"
#include "data/ThreeDCenter.h"
#include "data/PlayerCenter.h"
#include "data/BackgroundCenter.h"
#include "shapes3D/Shape3D.h"
#include "shapes3D/Point3D.h"
#include "shapes3D/Stick.h"
#include "3D/Camera.h"
#include "stickman/Stickman.h"
#include "enemies/EnemyA.h"
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_acodec.h>
#include <vector>
#include <cstring>
#include <iostream>
#include <cmath>
#include <memory>

// fixed settings
const char game_icon_img_path[] = "./assets/image/game_icon.png";

/**
 * @brief Game entry.
 * @details The function processes all allegro events and update the event state to a generic data storage (i.e. DataCenter).
 * For timer event, the game_update and game_draw function will be called if and only if the current is timer.
*/
void
Game::execute() {
	DataCenter *DC = DataCenter::get_instance();
	// main game loop
	// game start
	debug_log("Game state: change to START\n");
	state = STATE::START;
	al_start_timer(timer);
	bool run = true;
	while(run) {
		// process all events here
		al_wait_for_event(event_queue, &event);
		switch(event.type) {
			case ALLEGRO_EVENT_TIMER: {
				run &= game_update();
				game_draw();
				break;
			} case ALLEGRO_EVENT_DISPLAY_CLOSE: { // stop game
				run = false;
				break;
			} case ALLEGRO_EVENT_KEY_DOWN: {
				DC->key_state[event.keyboard.keycode] = true;
				game_keydown();
				break;
			} case ALLEGRO_EVENT_KEY_UP: {
				DC->key_state[event.keyboard.keycode] = false;
				game_keyup();
				break;
			} case ALLEGRO_EVENT_MOUSE_AXES: {
				DC->mouse.x = event.mouse.x;
				DC->mouse.y = event.mouse.y;
				break;
			} case ALLEGRO_EVENT_MOUSE_BUTTON_DOWN: {
				DC->mouse_state[event.mouse.button] = true;
				break;
			} case ALLEGRO_EVENT_MOUSE_BUTTON_UP: {
				DC->mouse_state[event.mouse.button] = false;
				break;
			} default: break;
		}
	}
}
void Game::game_keydown(){
	ThreeDCenter *TC = ThreeDCenter::get_instance();
	PlayerCenter *PC = PlayerCenter::get_instance();
	PC->keydown(event.keyboard.keycode);
	if(event.keyboard.keycode == ALLEGRO_KEY_TAB) TC->switch_view();
}
void Game::game_keyup(){
	PlayerCenter *PC = PlayerCenter::get_instance();
	PC->keyup(event.keyboard.keycode);
}
/**
 * @brief Initialize all allegro addons and the game body.
 * @details Only one timer is created since a game and all its data should be processed synchronously.
*/
Game::Game() {
	DataCenter *DC = DataCenter::get_instance();
	GAME_ASSERT(al_init(), "failed to initialize allegro.");

	// initialize allegro addons
	bool addon_init = true;
	addon_init &= al_init_primitives_addon();
	addon_init &= al_init_font_addon();
	addon_init &= al_init_ttf_addon();
	addon_init &= al_init_image_addon();
	addon_init &= al_init_acodec_addon();
	GAME_ASSERT(addon_init, "failed to initialize allegro addons.");

	// initialize events
	bool event_init = true;
	event_init &= al_install_keyboard();
	event_init &= al_install_mouse();
	event_init &= al_install_audio();
	GAME_ASSERT(event_init, "failed to initialize allegro events.");

	// initialize game body
	GAME_ASSERT(
		display = al_create_display(DC->window_width, DC->window_height),
		"failed to create display.");
	GAME_ASSERT(
		timer = al_create_timer(1.0 / DC->FPS),
		"failed to create timer.");
	GAME_ASSERT(
		event_queue = al_create_event_queue(),
		"failed to create event queue.");

	debug_log("Game initialized.\n");
	game_init();
}

/**
 * @brief Initialize all auxiliary resources.
*/
void
Game::game_init() {
	DataCenter *DC = DataCenter::get_instance();
	SoundCenter *SC = SoundCenter::get_instance();
	ImageCenter *IC = ImageCenter::get_instance();
	FontCenter *FC = FontCenter::get_instance();
	ThreeDCenter *TC = ThreeDCenter::get_instance();
	EnemyCenter *EC = EnemyCenter::get_instance();
	PlayerCenter *PC = PlayerCenter::get_instance();
	BackgroundCenter *BC = BackgroundCenter::get_instance();
	// set window icon
	game_icon = IC->get(game_icon_img_path);
	al_set_display_icon(display, game_icon);

	// register events to event_queue
    al_register_event_source(event_queue, al_get_display_event_source(display));
    al_register_event_source(event_queue, al_get_keyboard_event_source());
    al_register_event_source(event_queue, al_get_mouse_event_source());
    al_register_event_source(event_queue, al_get_timer_event_source(timer));

	// init sound setting
	SC->init();

	// init font setting
	FC->init();

	BC->init();

	ui = new UI();
	ui->init();


	auto ea1 = std::make_shared<EnemyA>();
	ea1->set_color(255,255,255);
	EC->add(ea1);

}

/**
 * @brief The function processes all data update.
 * @details The behavior of the whole game body is determined by its state.
 * @return Whether the game should keep running (true) or reaches the termination criteria (false).
 * @see Game::STATE
*/
bool
Game::game_update() {
	DataCenter *DC = DataCenter::get_instance();
	SoundCenter *SC = SoundCenter::get_instance();
	ThreeDCenter *TC = ThreeDCenter::get_instance();
	EnemyCenter *EC = EnemyCenter::get_instance();
	PlayerCenter *PC = PlayerCenter::get_instance();


	// If the game is not paused, we should progress update.
	if(state != STATE::PAUSE) {
		SC->update();
		ui->update();
		EC->update();
		PC->update();
		
		if(state != STATE::START) {
		}
	}
	// game_update is finished. The states of current frame will be previous states of the next frame.
	memcpy(DC->prev_key_state, DC->key_state, sizeof(DC->key_state));
	memcpy(DC->prev_mouse_state, DC->mouse_state, sizeof(DC->mouse_state));
	return true;
}

/**
 * @brief Draw the whole game and objects.
*/
void
Game::game_draw() {
	DataCenter *DC = DataCenter::get_instance();
	FontCenter *FC = FontCenter::get_instance();
	ThreeDCenter *TC = ThreeDCenter::get_instance();
	PlayerCenter *PC = PlayerCenter::get_instance();


	// Flush the screen first.
	al_clear_to_color(al_map_rgb(0, 0, 0));
	

	//Camera cam(1,1);
	TC->camera.theta = PC->player.theta + TC->shift_theta;
	TC->camera.phi = PC->player.phi;
	TC->camera.target = PC->player.pos;
	TC->draw();
	al_draw_line(100, 0, 0, 100, al_map_rgb(0, 0, 255), 10.0);
    al_draw_line(0, 0, 100, 100, al_map_rgb(255, 0, 0), 10.0);
    

	//Camera cam;
	
	
	
	
	switch (state)
	{
	case STATE::START:
		
		break;
	case STATE::PAUSE:
		break;
	case STATE::PREPARE:
		break;
	case STATE::END:
		break;
	}
	al_flip_display();
}

Game::~Game() {
	al_destroy_display(display);
	al_destroy_timer(timer);
	al_destroy_event_queue(event_queue);
}

